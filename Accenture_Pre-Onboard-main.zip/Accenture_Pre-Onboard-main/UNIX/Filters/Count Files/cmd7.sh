ls -r | wc -l
./ -type -f -print | wc -l