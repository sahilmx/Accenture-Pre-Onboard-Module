read a;
read b;
echo $((a + b));