public abstract class Bank{
    public abstract int getRateOfInterest();
}