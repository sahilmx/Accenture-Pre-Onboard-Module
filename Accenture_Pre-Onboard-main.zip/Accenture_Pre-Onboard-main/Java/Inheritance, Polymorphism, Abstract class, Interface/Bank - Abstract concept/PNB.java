public class PNB extends Bank{
    public int getRateOfInterest(){
        return 8;
    }
}