public class SBI extends Bank{
    public int getRateOfInterest(){
        return 7;
    }
}