insert into tickets values('T1', 'S5', NULL, 1, 2);
insert into tickets values('T2', 'S2', NULL, 5, 1);