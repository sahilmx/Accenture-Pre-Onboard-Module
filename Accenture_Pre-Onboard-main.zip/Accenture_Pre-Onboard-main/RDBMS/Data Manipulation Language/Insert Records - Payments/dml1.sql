insert into payments values('P1', 'T3', 1005, 'D3');
insert into payments values('P2', 'T2', 1004, 'D5');