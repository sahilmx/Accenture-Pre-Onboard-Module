update buses set type = 'ac' 
where bus_no = 33;