update schedule set travel_date = travel_date+5 
where destination = 'Bangalore' and source = 'Chennai';