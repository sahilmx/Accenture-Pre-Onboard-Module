delete from payments 
where discount_id = 'D1';