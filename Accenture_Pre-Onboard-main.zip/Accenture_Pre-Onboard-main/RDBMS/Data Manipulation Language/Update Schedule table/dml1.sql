update schedule set DESTINATION = 'Coimbatore'
where SCHEDULE_ID = 'S4';