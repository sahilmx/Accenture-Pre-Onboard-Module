select max(summertemp) as "HOT SUMMER" , min(wintertemp) as "CHILL WINTER" 
from town;