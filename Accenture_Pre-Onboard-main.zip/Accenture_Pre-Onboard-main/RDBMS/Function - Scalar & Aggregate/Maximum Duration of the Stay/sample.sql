select max(todate-fromdate) as MAXIMUMDAYS 
from booking;