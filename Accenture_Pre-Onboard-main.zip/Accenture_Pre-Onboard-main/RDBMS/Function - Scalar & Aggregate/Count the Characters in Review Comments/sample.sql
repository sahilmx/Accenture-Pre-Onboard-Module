select length(comments) as COMMENTS_LENGTH 
from review 
order by COMMENTS_LENGTH;