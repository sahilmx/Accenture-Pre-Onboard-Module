select INITCAP(name) as GUESTNAME 
from Guest 
order by GUESTNAME;