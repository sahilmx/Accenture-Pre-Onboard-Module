create TABLE product
( prod_id number(4) primary key,
  prod_name varchar2(25),
  prod_expiry_date date not null
); 