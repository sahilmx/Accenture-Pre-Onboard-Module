Create table Guest(
	guestID number,
  	name varchar(30),
    address varchar(30),
  	country varchar(20),
  	email varchar(30),
  	phone varchar(15),
  	constraint PK primary key(guestID)
);