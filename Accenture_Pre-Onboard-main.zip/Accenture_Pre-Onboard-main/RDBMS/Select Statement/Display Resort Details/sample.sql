select resortName, townname 
from Resort 
order by resortName;