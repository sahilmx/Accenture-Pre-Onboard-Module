select distinct bus_no from schedule
order by bus_no desc;