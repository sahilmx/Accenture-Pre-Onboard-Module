select bus_no, bus_name from buses
order by bus_name desc;