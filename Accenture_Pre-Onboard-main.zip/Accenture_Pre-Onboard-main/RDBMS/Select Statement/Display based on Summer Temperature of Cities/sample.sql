select townname 
from town 
where summertemp>30 
order by summertemp desc;