Select resortName 
from Resort 
where starRating between 4 and 5 
order by starRating;