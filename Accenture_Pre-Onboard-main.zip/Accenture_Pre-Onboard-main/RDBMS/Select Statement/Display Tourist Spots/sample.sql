select pointID, describe 
from pointofinterest 
where closetime >='8PM' 
order by pointID;